package com.cjits.service;

import com.cjits.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

        Optional<Optional<User>> findUsersByType(String userType);

        Optional<User> findUserById(Long id);

        Optional<User> findUserByUsername(String username);

        User createuser(User user);
        List<User> getAllUsers();
        Optional<User> findUserById(long id);
        User updateUser(Long id, User user);
        void deleteUser(Long id);

        Optional<Optional<User>> findUsersByUserType(String userType);
        public List<User> findAllUsers();
}
