package com.cjits.service;

import com.cjits.entity.User;
import com.cjits.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public List<User> getAllUsers() {
        try {
            return userRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error fetching users from database", e);
        }
    }

    @Override
    public Optional<User> findUserById(long id) {
        try {
            return userRepository.findById(id);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching user from database", e);
        }
    }

    @Override
    public Optional<Optional<User>> findUsersByUserType(String userType) {
        try {
            Optional<User> users = userRepository.findByUserType(userType);
            if (!users.isEmpty()) {
                return Optional.of(users);
            } else {
                return Optional.empty();
            }
        } catch (Exception e) {
            throw new RuntimeException("Error fetching users by user type from database", e);
        }
    }

    @Override
    public List<User> findAllUsers() {
        return null;
    }

    @Override
    public Optional<Optional<User>> findUsersByType(String userType) {
        return Optional.empty();
    }

    @Override
    public Optional<User> findUserById(Long id) {
        return Optional.empty();
    }

    @Override
    public Optional<User> findUserByUsername(String username) {
        try {
            return userRepository.findByUsername(username);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching user by username from database", e);
        }
    }

    @Override
    public User createuser(User user) {
        try {
            return userRepository.save(user);
        } catch (Exception e) {
            throw new RuntimeException("Error creating user in database", e);
        }
    }

//    @Override
//    public User createUser(User user) {
//        try {
//            return userRepository.save(user);
//        } catch (Exception e) {
//            throw new RuntimeException("Error creating user in database", e);
//        }
//    }

    @Override
    public User updateUser(Long id, User user) {
        try {
            Optional<User> userData = userRepository.findById(id);
            if (userData.isPresent()) {
                User existingUser = userData.get();
                existingUser.setUsername(user.getUsername());
                existingUser.setPassword(user.getPassword());
                existingUser.setEmail(user.getEmail());
                existingUser.setPhoneNumber(user.getPhoneNumber());
                existingUser.setAddress(user.getAddress());
                existingUser.setUserType(user.getUserType());
                return userRepository.save(existingUser);
            } else {
                throw new RuntimeException("User not found");
            }
        } catch (Exception e) {
            throw new RuntimeException("Error updating user in database", e);
        }
    }

    @Override
    public void deleteUser(Long id) {
        try {
            userRepository.deleteById(id);
        } catch (Exception e) {
            throw new RuntimeException("Error deleting user from database", e);
        }
    }
}
